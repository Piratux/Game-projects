#include "EventHandler.h"

int main(int argc, char** argv)
{
	Options options;
	init_options(&options);
	
	srand (time(NULL));

    SDL_Init(SDL_INIT_VIDEO);
	
    SDL_Window* window = SDL_CreateWindow("Master Mind", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                          30 * options.PIXEL_SIZE, 30 * options.PIXEL_SIZE, SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    
    Screen screen = create_screen(options.PIXEL_SIZE);
    
    Texture* textures = parse_textures();
    if(!textures)
    {
    	printf("Failed to load assets\n");
    	getchar();
    	return 0;
	}
    
    Menu menu;
    init_menu(&menu);
    
    Game game;
    init_game(&game);
    
    int state = MenuState;
    
    bool running = true;
    Uint32 previous_time = 0, curr_time = 0, delta;
    SDL_Event event;
    while (running)
    {
    	curr_time = SDL_GetTicks();
    	delta = curr_time - previous_time;
    	
    	state = handle_events(state, &event, &screen, &game, &menu);
    	if(state == QuitState)
    	{
    		running = false;
		}
    	
    	if(1000 / options.FPS <= delta)
    	{
    		previous_time = curr_time;
    		
    		switch(state)
	    	{
	    	case MenuState:
	    		draw_menu(&screen, textures, &menu);
	    		break;
	    	case GameState:
	    		draw_game(&screen, textures, &game, delta);
	    		break;
	    	case ScoreState:
	    		draw_score(&screen, textures, &game);
	    		break;
			}
			
	    	SDL_RenderClear(renderer);
	        update_screen(renderer, &screen);
	    	SDL_RenderPresent(renderer);
		}
    }
    
    free(textures);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}

