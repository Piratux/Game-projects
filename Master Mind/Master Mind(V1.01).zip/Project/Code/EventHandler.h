#pragma once

#include "Menu.h"
#include "GamePlay.h"
#include "Score.h"

enum States
{
	MenuState, GameState, ScoreState, QuitState
};

int handle_events(int state, SDL_Event* event, Screen* screen, Game* game, Menu* menu);
