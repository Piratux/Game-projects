#include "Score.h"

void draw_score(Screen* screen, Texture* tex, Game* game)
{
	float shade = -0.5f;
	SDL_Point mouse_pos = get_mouse_pos(screen);
	
	draw_image(screen, &tex[ScorePageIMG], tex[ScorePageIMG].pos, 0.0f);
	if(mouse_in_region(screen, 1, 28, 24, 28))
	{
		draw_image(screen, &tex[BackIMG], (SDL_Point){8, 24}, shade);
	}
	else
	{
		draw_image(screen, &tex[BackIMG], (SDL_Point){8, 24}, 0.0f);
	}
	
	for(int i = 0; i < game->total_scores; i++)
	{
		draw_number(screen, &tex[NumbersIMG], (SDL_Point){3, 2 + i * 7}, 0.0f, i+1);
		screen->data[6 + i * 7][7] = game->colours[Gray];
		
		time_t mins = game->scores[i] / 60;
		time_t seconds = game->scores[i] % 60;
		draw_number(screen, &tex[NumbersIMG], (SDL_Point){11, 2 + i * 7}, 0.0f, mins);
		draw_number(screen, &tex[NumbersIMG], (SDL_Point){17, 2 + i * 7}, 0.0f, floor(seconds / 10));
		draw_number(screen, &tex[NumbersIMG], (SDL_Point){21, 2 + i * 7}, 0.0f, seconds % 10);
		
		screen->data[3 + i * 7][15] = game->colours[Gray];
		screen->data[5 + i * 7][15] = game->colours[Gray];
	}
}
int score_mouse_pressed(Game* game, Screen* screen, Uint8 mouse_button)
{
	if(mouse_in_region(screen, 1, 28, 24, 28))
	{
		return 0;
	}
	return 2;
}
