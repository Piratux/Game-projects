#include "EventHandler.h"

int handle_events(int state, SDL_Event* event, Screen* screen, Game* game, Menu* menu)
{
	int handler_state = state;
	while (SDL_PollEvent(event))
    {
        if(event->type == SDL_QUIT)
        {
            handler_state = QuitState;
        }
        if(event->type == SDL_KEYDOWN)
		{
			const char* key = SDL_GetKeyName(event->key.keysym.sym);
			if (strcmp(key, "Escape") == 0)
    		{
    			handler_state = MenuState;
			}
		}
		if(event->type == SDL_MOUSEBUTTONDOWN && (event->button.button == SDL_BUTTON_LEFT || event->button.button == SDL_BUTTON_RIGHT))
		{
			switch(handler_state)
			{
			case MenuState:
				handler_state = menu_mouse_pressed(menu, screen, event->button.button);
				break;
			case GameState:
				handler_state = game_mouse_pressed(game, screen, event->button.button);
				break;
			case ScoreState:
				handler_state = score_mouse_pressed(game, screen, event->button.button);
				break;
			}
		}
		if(event->type == SDL_MOUSEWHEEL)
		{
			switch(handler_state)
			{
			case MenuState:
				menu_scroll(menu, -event->wheel.y);
				break;
			}
		}
    }
    return handler_state;
}
