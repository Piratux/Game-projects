#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h> // stat()
#include <unistd.h> // getcwd()
#include <windows.h> // OPENFILENAMEA
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
