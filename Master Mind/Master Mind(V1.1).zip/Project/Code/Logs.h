#pragma once

#include "Libraries.h"

void log_message(const char* msg);
void log_program_start();
void log_program_end();
