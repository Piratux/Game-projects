#include "GamePlay.h"

void init_game(Game* game)
{
	game->total_guesses = 0;
	game->state = GoState;
	
	game->colours[0] = (SDL_Color){255, 255, 255, 255}; //White
	game->colours[1] = (SDL_Color){245, 255, 60, 255}; //Yellow
	game->colours[2] = (SDL_Color){195, 24, 24, 255}; //Red
	game->colours[3] = (SDL_Color){99, 255, 60, 255}; //Green
	game->colours[4] = (SDL_Color){32, 22, 225, 255}; //Blue
	game->colours[5] = (SDL_Color){223, 104, 28, 255}; //Orange
	game->colours[6] = (SDL_Color){120, 120, 120, 255}; //Gray
	game->colours[7] = (SDL_Color){244, 99, 255, 255}; //Pink
	game->colours[8] = (SDL_Color){0, 0, 0, 255}; //Black
	
	for(int i = 0; i < 4; i++)
	{
		game->curr_guess[i] = 0;
	}
	
	game->timer = 0;
	game->second = 0;
	
	game->total_scores = 0;
}
void reset_game(Game* game)
{
	game->total_guesses = 0;
	game->state = GoState;
	
	for(int i = 0; i < 4; i++)
	{
		game->curr_guess[i] = 0;
	}
	
	game->timer = 0;
	game->second = 0;
}
void draw_game(Screen* screen, Texture* tex, Game* game, Uint32 delta)
{
	float shade = -0.5f;
	SDL_Point mouse_pos = get_mouse_pos(screen);
	
	draw_image(screen, &tex[GameIMG], tex[GameIMG].pos, 0.0f);
	draw_image(screen, &tex[AddIMG], tex[AddIMG].pos, 0.0f);
	switch(game->state)
	{
	case GoState:
		draw_image(screen, &tex[GoIMG], tex[GoIMG].pos, 0.0f);
		if(mouse_in_region(screen, 11, 13, 26, 28))
		{
			draw_image(screen, &tex[AddIMG], tex[AddIMG].pos, shade);
		}
		break;
	case WinState:
		draw_image(screen, &tex[WinIMG], tex[WinIMG].pos, 0.0f);
		for(int i = 0; i < 4; i++)
			screen->data[15][20 + i] = game->colours[game->secret_code[i]];
		break;
	case LoseState:
		draw_image(screen, &tex[LoseIMG], tex[LoseIMG].pos, 0.0f);
		for(int i = 0; i < 4; i++)
			screen->data[15][20 + i] = game->colours[game->secret_code[i]];
		break;
	}
	draw_guesses(game, screen);
	draw_timer(screen, tex, game);
	
	if(mouse_in_region(screen, 15, 28, 24, 28))
		draw_image(screen, &tex[NewIMG], tex[NewIMG].pos, shade);
	else
		draw_image(screen, &tex[NewIMG], tex[NewIMG].pos, 0.0f);
	
	if(mouse_in_region(screen, 15, 28, 1, 5))
		draw_image(screen, &tex[BackIMG], tex[BackIMG].pos, shade);
	else
		draw_image(screen, &tex[BackIMG], tex[BackIMG].pos, 0.0f);
	
	if(game->state == GoState && game->timer < 599 && game->total_guesses > 0)
		game->second += delta;
    if(game->second >= 1000)
    {
    	game->second = 0;
    	game->timer++;
    }
}
void draw_timer(Screen* screen, Texture* tex, Game* game)
{
	time_t mins = game->timer / 60;
	time_t seconds = game->timer % 60;
	draw_number(screen, &tex[NumbersIMG], (SDL_Point){16, 18}, 0.0f, mins);
	draw_number(screen, &tex[NumbersIMG], (SDL_Point){22, 18}, 0.0f, floor(seconds / 10));
	draw_number(screen, &tex[NumbersIMG], (SDL_Point){26, 18}, 0.0f, seconds % 10);
	
	screen->data[19][20] = game->colours[6];
	screen->data[21][20] = game->colours[6];
}
void draw_guesses(Game* game, Screen* screen)
{
	for(int i = 0; i < 4; i++)
	{
		SDL_Point mouse_pos = get_mouse_pos(screen);
		
		// Draw shaded colour guess buttons if mouse is hovered
		if(game->state == GoState)
			if(mouse_pos.x == 2 + i * 2 && mouse_pos.y == 27)
				screen->data[27][2 + i * 2] = shade_RGB_pixel(game->colours[game->curr_guess[i]], 0.3f);
		else
			screen->data[27][2 + i * 2] = game->colours[game->curr_guess[i]];
		
		// Draw previous guesses
		for(int j = 0; j < game->total_guesses; j++)
		{
			screen->data[24 - j * 2][2 + i * 2] = game->colours[game->guesses[j][i]];
			screen->data[24 - j * 2][10 + i] = game->colours[game->evaluation[j][i]];
		}
	}
}
int game_mouse_pressed(Game* game, Screen* screen, Uint8 mouse_button)
{
	SDL_Point mouse_pos = get_mouse_pos(screen);
	
	// For debugging reasons only, no cheating :)
	//printf("%i %i %i %i\n", game->secret_code[0], game->secret_code[1], game->secret_code[2], game->secret_code[3]);
	
	//printf("%i %i\n", mouse_pos.x, mouse_pos.y);
	
	if(mouse_in_region(screen, 15, 28, 1, 5))
	{
		return 0;
	}
	
	if(game->state == GoState)
	{
		// Colour guess buttons
		if(mouse_pos.y == 27)
		{
			int direction = (mouse_button == SDL_BUTTON_LEFT) ? 1 : -1;
			if(mouse_pos.x == 2)
				change_guess(game, screen, 0, direction);
			if(mouse_pos.x == 4)
				change_guess(game, screen, 1, direction);
			if(mouse_pos.x == 6)
				change_guess(game, screen, 2, direction);
			if(mouse_pos.x == 8)
				change_guess(game, screen, 3, direction);
		}
		// Add colour guess
		if(mouse_in_region(screen, 11, 13, 26, 28))
		{
			// Prevents instantly guessing code
			if(game->total_guesses == 0)
			{
				generate_code(game);
			}
			add_guess(game, screen);
		}
	}
	// New game
	if(mouse_in_region(screen, 15, 28, 24, 28))
	{
		reset_game(game);
		draw_guesses(game, screen);
	}
	return 1;
}
void generate_code(Game* game)
{
	int total_same = 0;
	while(total_same < 4)
	{
		for(int i = 0; i < 4; i++)
		{
			game->secret_code[i] = rand()%8;
		}
		for(int i = 0; i < 4; i++)
		{
			total_same += (game->secret_code[i] == game->curr_guess[i]);
		}
	}
}
void change_guess(Game* game, Screen* screen, int idx, int direction)
{
	game->curr_guess[idx] += direction;
	if(game->curr_guess[idx] > 7)
	{
		game->curr_guess[idx] = 0;
	}
	if(game->curr_guess[idx] < 0)
	{
		game->curr_guess[idx] = 7;
	}
	draw_guesses(game, screen);
}
void add_guess(Game* game, Screen* screen)
{
	game->guesses[game->total_guesses][0] = game->curr_guess[0];
	game->guesses[game->total_guesses][1] = game->curr_guess[1];
	game->guesses[game->total_guesses][2] = game->curr_guess[2];
	game->guesses[game->total_guesses][3] = game->curr_guess[3];
	evaluate_guess(game, screen);
	game->total_guesses++;
	draw_guesses(game, screen);
}
void evaluate_guess(Game* game, Screen* screen)
{
	int white = 0, red = 0;
	for(int i = 0; i < 4; i++)
	{
		if(game->guesses[game->total_guesses][i] == game->secret_code[i])
		{
			red++;
		}
		else
		{
			for(int j = 0; j < 4; j++)
			{
				if(i != j)
				{
					if(game->guesses[game->total_guesses][j] == game->secret_code[i])
					{
						white++;
						break;
					}
				}
			}
		}
	}
	int guessed = 0;
	for(int i = guessed; i < red; i++)
	{
		game->evaluation[game->total_guesses][guessed++] = Red;
	}
	for(int i = guessed; i < red + white; i++)
	{
		game->evaluation[game->total_guesses][guessed++] = White;
	}
	for(int i = red + white; i < 4; i++)
	{
		game->evaluation[game->total_guesses][i] = Black;
	}

	if(red == 4)
	{
		game->state = WinState;
		add_score(game);
	}
	else if(game->total_guesses == 11)
		game->state = LoseState;
	
	draw_guesses(game, screen);
}
void add_score(Game* game)
{
	game->scores[game->total_scores++] = game->timer;
	
	for(int j = game->total_scores-1; j > 0; j--)
	{
		if(game->scores[j] > game->scores[j-1])
		{
			break;
		}
		// swap scores
		game->scores[j] ^= game->scores[j-1] ^= game->scores[j] ^= game->scores[j-1];
	}
	
	if(game->total_scores == 4)
	{
		game->total_scores--;
	}
}
