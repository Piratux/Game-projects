LeftMouseButton: place pogger (green)
RightMouseButton: place pogchamp (blue and it can only be placed once)
(Shift + LeftMouseButton) or (Shift + RightMouseButton): clear tile
MouseScroll: zoom in/out
MouseButton: pan (move around)